#ifndef ORTAK_H
#define ORTAK_H

#define MAX_KITAP 100
#define MAX_KULLANICI 100
#define MAX_ODUNC 200
#define ODUNC_SURESI 14

struct Kitap {
    char isbn[20];
    char ad[50];
    char yazar[50];
    char yayinevi[50];
    char konum[30];
    int yil;
    int stok;
};

struct Kullanici {
    char kullaniciNo[20];
    char adSoyad[50];
    char sifre[20];
    char rol[20];
};

struct OduncKaydi {
    char kullaniciNo[20];
    char isbn[20];
    char oduncTarih[15];
    char iadeTarih[15];
    char durum[20];
};

extern struct Kitap kitaplar[MAX_KITAP];
extern struct Kullanici kullanicilar[MAX_KULLANICI];
extern struct OduncKaydi oduncKayitlari[MAX_ODUNC];

extern int kitapSayisi;
extern int kullaniciSayisi;
extern int oduncSayisi;

void satirSonuTemizle(char *str);
int tarihGunFarki(char tarih1[], char tarih2[]);
void bugununTarihi(char tarih[]);

#endif
