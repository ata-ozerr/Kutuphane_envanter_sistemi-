KUTUPHANE OTOMASYONU - MODULER C PROJESI

Dosyalar:
- main.c        : Ana menu ve program akisi
- ortak.h/c     : Ortak structlar, global diziler ve yardimci fonksiyonlar
- kitap.h/c     : Kitap ekleme, silme, arama, listeleme, guncelleme
- kullanici.h/c : Kullanici ekleme, silme, listeleme, giris islemleri
- odunc.h/c     : Odunc alma, iade etme, gecikenleri listeleme
- rapor.h/c     : Gelismis raporlama

Derleme komutu:
gcc main.c ortak.c kitap.c kullanici.c odunc.c rapor.c -o kutuphane

Calistirma:
./kutuphane

Windows'ta:
kutuphane.exe

Ilk giris:
Kullanici no: 1
Sifre: 1234

Program ilk acildiginda kullanicilar.txt yoksa otomatik admin olusturur.
Olusan txt dosyalari:
- kitaplar.txt
- kullanicilar.txt
- odunc_kayitlari.txt
