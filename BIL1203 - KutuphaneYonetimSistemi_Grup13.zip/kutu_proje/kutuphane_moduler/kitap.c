#include <stdio.h>
#include <string.h>
#include "ortak.h"
#include "kitap.h"
#include "odunc.h"

int isbnIleKitapBul(char isbn[]) {
    for(int i = 0; i < kitapSayisi; i++) {
        if(strcmp(kitaplar[i].isbn, isbn) == 0) {
            return i;
        }
    }
    return -1;
}

void kitaplariKaydet() {
    FILE *dosya = fopen("kitaplar.txt", "w");

    if(dosya == NULL) {
        printf("kitaplar.txt acilamadi.\n");
        return;
    }

    for(int i = 0; i < kitapSayisi; i++) {
        fprintf(dosya, "%s\t%s\t%s\t%s\t%d\t%d\t%s\n",
                kitaplar[i].isbn,
                kitaplar[i].ad,
                kitaplar[i].yazar,
                kitaplar[i].yayinevi,
                kitaplar[i].yil,
                kitaplar[i].stok,
                kitaplar[i].konum);
    }

    fclose(dosya);
}

void kitaplariOku() {
    FILE *dosya = fopen("kitaplar.txt", "r");

    if(dosya == NULL) {
        return;
    }

    while(fscanf(dosya, "%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%d\t%d\t%[^\n]\n",
                 kitaplar[kitapSayisi].isbn,
                 kitaplar[kitapSayisi].ad,
                 kitaplar[kitapSayisi].yazar,
                 kitaplar[kitapSayisi].yayinevi,
                 &kitaplar[kitapSayisi].yil,
                 &kitaplar[kitapSayisi].stok,
                 kitaplar[kitapSayisi].konum) == 7) {

        kitapSayisi++;

        if(kitapSayisi >= MAX_KITAP) {
            break;
        }
    }

    fclose(dosya);
}

void kitapBilgiYazdir(int i) {
    printf("ISBN: %s\n", kitaplar[i].isbn);
    printf("Ad: %s\n", kitaplar[i].ad);
    printf("Yazar: %s\n", kitaplar[i].yazar);
    printf("Yayinevi: %s\n", kitaplar[i].yayinevi);
    printf("Yil: %d\n", kitaplar[i].yil);
    printf("Stok: %d\n", kitaplar[i].stok);
    printf("Konum: %s\n", kitaplar[i].konum);
    printf("-------------------\n");
}

void kitapEkle() {
    if(kitapSayisi >= MAX_KITAP) {
        printf("Daha fazla kitap eklenemez.\n");
        return;
    }

    printf("\nISBN: ");
    fgets(kitaplar[kitapSayisi].isbn, 20, stdin);
    satirSonuTemizle(kitaplar[kitapSayisi].isbn);

    if(isbnIleKitapBul(kitaplar[kitapSayisi].isbn) != -1) {
        printf("Bu ISBN zaten kayitli.\n");
        return;
    }

    printf("Kitap adi: ");
    fgets(kitaplar[kitapSayisi].ad, 50, stdin);
    satirSonuTemizle(kitaplar[kitapSayisi].ad);

    printf("Yazar: ");
    fgets(kitaplar[kitapSayisi].yazar, 50, stdin);
    satirSonuTemizle(kitaplar[kitapSayisi].yazar);

    printf("Yayinevi: ");
    fgets(kitaplar[kitapSayisi].yayinevi, 50, stdin);
    satirSonuTemizle(kitaplar[kitapSayisi].yayinevi);

    printf("Yayin yili: ");
    scanf("%d", &kitaplar[kitapSayisi].yil);

    printf("Stok: ");
    scanf("%d", &kitaplar[kitapSayisi].stok);
    getchar();

    printf("Konum: ");
    fgets(kitaplar[kitapSayisi].konum, 30, stdin);
    satirSonuTemizle(kitaplar[kitapSayisi].konum);

    kitapSayisi++;
    kitaplariKaydet();

    printf("Kitap eklendi.\n");
}

void kitapListele() {
    if(kitapSayisi == 0) {
        printf("Kayitli kitap yok.\n");
        return;
    }

    printf("\n--- KITAP LISTESI ---\n");

    for(int i = 0; i < kitapSayisi; i++) {
        kitapBilgiYazdir(i);
    }
}

void kitapAra() {
    char aranacak[50];
    int secim, bulundu = 0;

    printf("\n1- ISBN ile ara\n");
    printf("2- Kitap adi ile ara\n");
    printf("3- Yazar ile ara\n");
    printf("Secim: ");
    scanf("%d", &secim);
    getchar();

    printf("Aranacak bilgi: ");
    fgets(aranacak, 50, stdin);
    satirSonuTemizle(aranacak);

    for(int i = 0; i < kitapSayisi; i++) {
        if((secim == 1 && strcmp(aranacak, kitaplar[i].isbn) == 0) ||
           (secim == 2 && strstr(kitaplar[i].ad, aranacak) != NULL) ||
           (secim == 3 && strstr(kitaplar[i].yazar, aranacak) != NULL)) {

            kitapBilgiYazdir(i);
            bulundu = 1;
        }
    }

    if(!bulundu) {
        printf("Kitap bulunamadi.\n");
    }
}

void kitapSil() {
    char isbn[20];

    printf("\nSilinecek ISBN: ");
    fgets(isbn, 20, stdin);
    satirSonuTemizle(isbn);

    int index = isbnIleKitapBul(isbn);

    if(index == -1) {
        printf("Kitap bulunamadi.\n");
        return;
    }

    if(kitapAktifOduncteMi(isbn)) {
        printf("Bu kitap oduncte oldugu icin silinemez.\n");
        return;
    }

    for(int i = index; i < kitapSayisi - 1; i++) {
        kitaplar[i] = kitaplar[i + 1];
    }

    kitapSayisi--;
    kitaplariKaydet();

    printf("Kitap silindi.\n");
}

void kitapGuncelle() {
    char isbn[20];

    printf("\nGuncellenecek ISBN: ");
    fgets(isbn, 20, stdin);
    satirSonuTemizle(isbn);

    int index = isbnIleKitapBul(isbn);

    if(index == -1) {
        printf("Kitap bulunamadi.\n");
        return;
    }

    printf("Yeni kitap adi: ");
    fgets(kitaplar[index].ad, 50, stdin);
    satirSonuTemizle(kitaplar[index].ad);

    printf("Yeni yazar: ");
    fgets(kitaplar[index].yazar, 50, stdin);
    satirSonuTemizle(kitaplar[index].yazar);

    printf("Yeni yayinevi: ");
    fgets(kitaplar[index].yayinevi, 50, stdin);
    satirSonuTemizle(kitaplar[index].yayinevi);

    printf("Yeni yil: ");
    scanf("%d", &kitaplar[index].yil);

    printf("Yeni stok: ");
    scanf("%d", &kitaplar[index].stok);
    getchar();

    printf("Yeni konum: ");
    fgets(kitaplar[index].konum, 30, stdin);
    satirSonuTemizle(kitaplar[index].konum);

    kitaplariKaydet();

    printf("Kitap guncellendi.\n");
}

void kitapSiralaAdaGore() {
    struct Kitap gecici;

    for(int i = 0; i < kitapSayisi - 1; i++) {
        for(int j = i + 1; j < kitapSayisi; j++) {
            if(strcmp(kitaplar[i].ad, kitaplar[j].ad) > 0) {
                gecici = kitaplar[i];
                kitaplar[i] = kitaplar[j];
                kitaplar[j] = gecici;
            }
        }
    }

    kitapListele();
}
