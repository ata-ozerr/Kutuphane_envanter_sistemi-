#include <stdio.h>
#include "kitap.h"
#include "kullanici.h"
#include "odunc.h"
#include "rapor.h"

int main() {
    int secim, rol;

    kitaplariOku();
    kullanicilariOku();
    oduncKayitlariniOku();

    rol = girisYap();

    if(rol == 0) {
        return 0;
    }

    while(1) {
        printf("\n===== KUTUPHANE SISTEMI =====\n");
        printf("1- Kitap Ekle\n");
        printf("2- Kitap Listele\n");
        printf("3- Kitap Ara\n");
        printf("4- Kitap Sil\n");
        printf("5- Odunc Al\n");
        printf("6- Iade Et\n");
        printf("7- Kitap Guncelle\n");
        printf("8- Kitaplari Ada Gore Sirala\n");
        printf("9- Rapor Goster\n");
        printf("10- Kullanici Ekle\n");
        printf("11- Kullanici Listele\n");
        printf("12- Kullanici Sil\n");
        printf("13- Odunc Kayitlarini Listele\n");
        printf("14- Geciken Kitaplari Listele\n");
        printf("0- Cikis\n");
        printf("Secim: ");
        scanf("%d", &secim);
        getchar();

        if(rol == 3 && !(secim == 2 || secim == 3 || secim == 5 || secim == 0)) {
            printf("Bu islem icin yetkiniz yok.\n");
            continue;
        }

        if(rol == 2 && !(secim == 1 || secim == 2 || secim == 3 ||
                          secim == 5 || secim == 6 || secim == 7 ||
                          secim == 8 || secim == 13 || secim == 14 || secim == 0)) {
            printf("Bu islem icin yetkiniz yok.\n");
            continue;
        }

        switch(secim) {
            case 1: kitapEkle(); break;
            case 2: kitapListele(); break;
            case 3: kitapAra(); break;
            case 4: kitapSil(); break;
            case 5: oduncAl(); break;
            case 6: iadeEt(); break;
            case 7: kitapGuncelle(); break;
            case 8: kitapSiralaAdaGore(); break;
            case 9: raporGoster(); break;
            case 10: kullaniciEkle(); break;
            case 11: kullaniciListele(); break;
            case 12: kullaniciSil(); break;
            case 13: oduncKayitlariniListele(); break;
            case 14: gecikenleriListele(); break;
            case 0:
                printf("Program kapatildi.\n");
                return 0;
            default:
                printf("Gecersiz secim.\n");
        }
    }
}
