#include <stdio.h>
#include <string.h>
#include "ortak.h"
#include "kullanici.h"
#include "odunc.h"

int kullaniciNoIleBul(char kullaniciNo[]) {
    for(int i = 0; i < kullaniciSayisi; i++) {
        if(strcmp(kullanicilar[i].kullaniciNo, kullaniciNo) == 0) {
            return i;
        }
    }
    return -1;
}

void kullanicilariKaydet() {
    FILE *dosya = fopen("kullanicilar.txt", "w");

    if(dosya == NULL) {
        printf("kullanicilar.txt acilamadi.\n");
        return;
    }

    for(int i = 0; i < kullaniciSayisi; i++) {
        fprintf(dosya, "%s\t%s\t%s\t%s\n",
                kullanicilar[i].kullaniciNo,
                kullanicilar[i].adSoyad,
                kullanicilar[i].sifre,
                kullanicilar[i].rol);
    }

    fclose(dosya);
}

void varsayilanAdminOlustur() {
    if(kullaniciSayisi == 0) {
        strcpy(kullanicilar[0].kullaniciNo, "1");
        strcpy(kullanicilar[0].adSoyad, "Admin Kullanici");
        strcpy(kullanicilar[0].sifre, "1234");
        strcpy(kullanicilar[0].rol, "admin");

        kullaniciSayisi = 1;
        kullanicilariKaydet();

        printf("Varsayilan admin olusturuldu.\n");
        printf("Kullanici No: 1\n");
        printf("Sifre: 1234\n");
    }
}

void kullanicilariOku() {
    FILE *dosya = fopen("kullanicilar.txt", "r");

    if(dosya == NULL) {
        varsayilanAdminOlustur();
        return;
    }

    while(fscanf(dosya, "%[^\t]\t%[^\t]\t%[^\t]\t%[^\n]\n",
                 kullanicilar[kullaniciSayisi].kullaniciNo,
                 kullanicilar[kullaniciSayisi].adSoyad,
                 kullanicilar[kullaniciSayisi].sifre,
                 kullanicilar[kullaniciSayisi].rol) == 4) {

        kullaniciSayisi++;

        if(kullaniciSayisi >= MAX_KULLANICI) {
            break;
        }
    }

    fclose(dosya);

    if(kullaniciSayisi == 0) {
        varsayilanAdminOlustur();
    }
}

void kullaniciEkle() {
    if(kullaniciSayisi >= MAX_KULLANICI) {
        printf("Daha fazla kullanici eklenemez.\n");
        return;
    }

    printf("\nKullanici no: ");
    fgets(kullanicilar[kullaniciSayisi].kullaniciNo, 20, stdin);
    satirSonuTemizle(kullanicilar[kullaniciSayisi].kullaniciNo);

    if(kullaniciNoIleBul(kullanicilar[kullaniciSayisi].kullaniciNo) != -1) {
        printf("Bu kullanici zaten kayitli.\n");
        return;
    }

    printf("Ad Soyad: ");
    fgets(kullanicilar[kullaniciSayisi].adSoyad, 50, stdin);
    satirSonuTemizle(kullanicilar[kullaniciSayisi].adSoyad);

    printf("Sifre: ");
    fgets(kullanicilar[kullaniciSayisi].sifre, 20, stdin);
    satirSonuTemizle(kullanicilar[kullaniciSayisi].sifre);

    printf("Rol admin/personel/ogrenci: ");
    fgets(kullanicilar[kullaniciSayisi].rol, 20, stdin);
    satirSonuTemizle(kullanicilar[kullaniciSayisi].rol);

    if(strcmp(kullanicilar[kullaniciSayisi].rol, "admin") != 0 &&
       strcmp(kullanicilar[kullaniciSayisi].rol, "personel") != 0 &&
       strcmp(kullanicilar[kullaniciSayisi].rol, "ogrenci") != 0) {
        printf("Gecersiz rol girdiniz.\n");
        return;
    }

    kullaniciSayisi++;
    kullanicilariKaydet();

    printf("Kullanici eklendi.\n");
}

void kullaniciListele() {
    if(kullaniciSayisi == 0) {
        printf("Kayitli kullanici yok.\n");
        return;
    }

    printf("\n--- KULLANICI LISTESI ---\n");

    for(int i = 0; i < kullaniciSayisi; i++) {
        printf("No: %s\n", kullanicilar[i].kullaniciNo);
        printf("Ad Soyad: %s\n", kullanicilar[i].adSoyad);
        printf("Sifre: %s\n", kullanicilar[i].sifre);
        printf("Rol: %s\n", kullanicilar[i].rol);
        printf("-------------------\n");
    }
}

void kullaniciSil() {
    char kullaniciNo[20];

    printf("\nSilinecek kullanici no: ");
    fgets(kullaniciNo, 20, stdin);
    satirSonuTemizle(kullaniciNo);

    int index = kullaniciNoIleBul(kullaniciNo);

    if(index == -1) {
        printf("Kullanici bulunamadi.\n");
        return;
    }

    if(kullaniciAktifOduncteMi(kullaniciNo)) {
        printf("Bu kullanicinin iade etmedigi kitap var. Silinemez.\n");
        return;
    }

    for(int i = index; i < kullaniciSayisi - 1; i++) {
        kullanicilar[i] = kullanicilar[i + 1];
    }

    kullaniciSayisi--;
    kullanicilariKaydet();

    printf("Kullanici silindi.\n");
}

int girisYap() {
    char kullaniciNo[20], sifre[20];

    printf("\n===== SISTEM GIRISI =====\n");
    printf("Kullanici no: ");
    scanf("%s", kullaniciNo);

    printf("Sifre: ");
    scanf("%s", sifre);
    getchar();

    for(int i = 0; i < kullaniciSayisi; i++) {
        if(strcmp(kullanicilar[i].kullaniciNo, kullaniciNo) == 0 &&
           strcmp(kullanicilar[i].sifre, sifre) == 0) {

            printf("Giris basarili.\n");
            printf("Kullanici: %s\n", kullanicilar[i].adSoyad);
            printf("Rol: %s\n", kullanicilar[i].rol);

            if(strcmp(kullanicilar[i].rol, "admin") == 0) {
                return 1;
            } else if(strcmp(kullanicilar[i].rol, "personel") == 0) {
                return 2;
            } else if(strcmp(kullanicilar[i].rol, "ogrenci") == 0) {
                return 3;
            }
        }
    }

    printf("Hatali kullanici no veya sifre.\n");
    return 0;
}
