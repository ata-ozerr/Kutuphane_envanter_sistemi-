#include <stdio.h>
#include <string.h>
#include <time.h>
#include "ortak.h"

struct Kitap kitaplar[MAX_KITAP];
struct Kullanici kullanicilar[MAX_KULLANICI];
struct OduncKaydi oduncKayitlari[MAX_ODUNC];

int kitapSayisi = 0;
int kullaniciSayisi = 0;
int oduncSayisi = 0;

void satirSonuTemizle(char *str) {
    size_t uzunluk = strlen(str);
    if (uzunluk > 0 && str[uzunluk - 1] == '\n') {
        str[uzunluk - 1] = '\0';
    }
}

int tarihGunFarki(char tarih1[], char tarih2[]) {
    int g1, a1, y1, g2, a2, y2;

    sscanf(tarih1, "%d/%d/%d", &g1, &a1, &y1);
    sscanf(tarih2, "%d/%d/%d", &g2, &a2, &y2);

    struct tm t1 = {0}, t2 = {0};

    t1.tm_mday = g1;
    t1.tm_mon = a1 - 1;
    t1.tm_year = y1 - 1900;

    t2.tm_mday = g2;
    t2.tm_mon = a2 - 1;
    t2.tm_year = y2 - 1900;

    return (int)(difftime(mktime(&t2), mktime(&t1)) / (60 * 60 * 24));
}

void bugununTarihi(char tarih[]) {
    time_t simdi = time(NULL);
    struct tm *zaman = localtime(&simdi);

    sprintf(tarih, "%02d/%02d/%04d",
            zaman->tm_mday,
            zaman->tm_mon + 1,
            zaman->tm_year + 1900);
}
