#ifndef KULLANICI_H
#define KULLANICI_H

void kullanicilariOku();
void kullanicilariKaydet();
void varsayilanAdminOlustur();
int kullaniciNoIleBul(char kullaniciNo[]);
int girisYap();

void kullaniciEkle();
void kullaniciListele();
void kullaniciSil();

#endif
