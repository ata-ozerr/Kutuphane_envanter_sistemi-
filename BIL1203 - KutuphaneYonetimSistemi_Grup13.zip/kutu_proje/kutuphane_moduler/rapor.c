#include <stdio.h>
#include <string.h>
#include "ortak.h"
#include "rapor.h"

void raporGoster() {
    int toplamStok = 0;
    int aktifOdunc = 0;
    int iadeEdilen = 0;
    int geciken = 0;
    int stoguBiten = 0;

    char bugun[15];
    bugununTarihi(bugun);

    for(int i = 0; i < kitapSayisi; i++) {
        toplamStok += kitaplar[i].stok;

        if(kitaplar[i].stok == 0) {
            stoguBiten++;
        }
    }

    for(int i = 0; i < oduncSayisi; i++) {
        if(strcmp(oduncKayitlari[i].durum, "IADE_EDILMEDI") == 0) {
            aktifOdunc++;

            int fark = tarihGunFarki(oduncKayitlari[i].oduncTarih, bugun);
            if(fark > ODUNC_SURESI) {
                geciken++;
            }
        } else {
            iadeEdilen++;
        }
    }

    printf("\n--- GELISMIS RAPOR ---\n");
    printf("Kitap turu sayisi: %d\n", kitapSayisi);
    printf("Toplam stok: %d\n", toplamStok);
    printf("Stogu biten kitap turu: %d\n", stoguBiten);
    printf("Kullanici sayisi: %d\n", kullaniciSayisi);
    printf("Toplam odunc kaydi: %d\n", oduncSayisi);
    printf("Aktif odunc: %d\n", aktifOdunc);
    printf("Iade edilen: %d\n", iadeEdilen);
    printf("Geciken kitap sayisi: %d\n", geciken);
}
