#ifndef ODUNC_H
#define ODUNC_H

void oduncKayitlariniOku();
void oduncKayitlariniKaydet();

void oduncAl();
void iadeEt();
void oduncKayitlariniListele();
void gecikenleriListele();

int kullaniciAktifOduncteMi(char kullaniciNo[]);
int kitapAktifOduncteMi(char isbn[]);

#endif
