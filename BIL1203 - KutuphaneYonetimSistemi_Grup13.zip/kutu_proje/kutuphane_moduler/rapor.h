#ifndef RAPOR_H
#define RAPOR_H

void raporGoster();

#endif
