#include <stdio.h>
#include <string.h>
#include "ortak.h"
#include "kitap.h"
#include "kullanici.h"
#include "odunc.h"

void oduncKayitlariniKaydet() {
    FILE *dosya = fopen("odunc_kayitlari.txt", "w");

    if(dosya == NULL) {
        printf("odunc_kayitlari.txt acilamadi.\n");
        return;
    }

    for(int i = 0; i < oduncSayisi; i++) {
        fprintf(dosya, "%s\t%s\t%s\t%s\t%s\n",
                oduncKayitlari[i].kullaniciNo,
                oduncKayitlari[i].isbn,
                oduncKayitlari[i].oduncTarih,
                oduncKayitlari[i].iadeTarih,
                oduncKayitlari[i].durum);
    }

    fclose(dosya);
}

void oduncKayitlariniOku() {
    FILE *dosya = fopen("odunc_kayitlari.txt", "r");

    if(dosya == NULL) {
        return;
    }

    while(fscanf(dosya, "%[^\t]\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\n]\n",
                 oduncKayitlari[oduncSayisi].kullaniciNo,
                 oduncKayitlari[oduncSayisi].isbn,
                 oduncKayitlari[oduncSayisi].oduncTarih,
                 oduncKayitlari[oduncSayisi].iadeTarih,
                 oduncKayitlari[oduncSayisi].durum) == 5) {

        oduncSayisi++;

        if(oduncSayisi >= MAX_ODUNC) {
            break;
        }
    }

    fclose(dosya);
}

int kullaniciAktifOduncteMi(char kullaniciNo[]) {
    for(int i = 0; i < oduncSayisi; i++) {
        if(strcmp(oduncKayitlari[i].kullaniciNo, kullaniciNo) == 0 &&
           strcmp(oduncKayitlari[i].durum, "IADE_EDILMEDI") == 0) {
            return 1;
        }
    }
    return 0;
}

int kitapAktifOduncteMi(char isbn[]) {
    for(int i = 0; i < oduncSayisi; i++) {
        if(strcmp(oduncKayitlari[i].isbn, isbn) == 0 &&
           strcmp(oduncKayitlari[i].durum, "IADE_EDILMEDI") == 0) {
            return 1;
        }
    }
    return 0;
}

void oduncAl() {
    char isbn[20], kullaniciNo[20], tarih[15];

    if(oduncSayisi >= MAX_ODUNC) {
        printf("Daha fazla odunc kaydi eklenemez.\n");
        return;
    }

    printf("\nISBN: ");
    fgets(isbn, 20, stdin);
    satirSonuTemizle(isbn);

    int kitapIndex = isbnIleKitapBul(isbn);

    if(kitapIndex == -1) {
        printf("Kitap bulunamadi.\n");
        return;
    }

    if(kitaplar[kitapIndex].stok <= 0) {
        printf("Kitap stokta yok.\n");
        return;
    }

    printf("Kullanici no: ");
    fgets(kullaniciNo, 20, stdin);
    satirSonuTemizle(kullaniciNo);

    if(kullaniciNoIleBul(kullaniciNo) == -1) {
        printf("Kullanici bulunamadi.\n");
        return;
    }

    printf("Odunc tarihi GG/AA/YYYY: ");
    fgets(tarih, 15, stdin);
    satirSonuTemizle(tarih);

    kitaplar[kitapIndex].stok--;

    strcpy(oduncKayitlari[oduncSayisi].kullaniciNo, kullaniciNo);
    strcpy(oduncKayitlari[oduncSayisi].isbn, isbn);
    strcpy(oduncKayitlari[oduncSayisi].oduncTarih, tarih);
    strcpy(oduncKayitlari[oduncSayisi].iadeTarih, "-");
    strcpy(oduncKayitlari[oduncSayisi].durum, "IADE_EDILMEDI");

    oduncSayisi++;

    kitaplariKaydet();
    oduncKayitlariniKaydet();

    printf("Kitap odunc verildi.\n");
}

void iadeEt() {
    char isbn[20], kullaniciNo[20], iadeTarih[15];

    printf("\nISBN: ");
    fgets(isbn, 20, stdin);
    satirSonuTemizle(isbn);

    printf("Kullanici no: ");
    fgets(kullaniciNo, 20, stdin);
    satirSonuTemizle(kullaniciNo);

    int kitapIndex = isbnIleKitapBul(isbn);

    if(kitapIndex == -1) {
        printf("Kitap bulunamadi.\n");
        return;
    }

    for(int i = 0; i < oduncSayisi; i++) {
        if(strcmp(oduncKayitlari[i].isbn, isbn) == 0 &&
           strcmp(oduncKayitlari[i].kullaniciNo, kullaniciNo) == 0 &&
           strcmp(oduncKayitlari[i].durum, "IADE_EDILMEDI") == 0) {

            printf("Iade tarihi GG/AA/YYYY: ");
            fgets(iadeTarih, 15, stdin);
            satirSonuTemizle(iadeTarih);

            strcpy(oduncKayitlari[i].iadeTarih, iadeTarih);
            strcpy(oduncKayitlari[i].durum, "IADE_EDILDI");

            kitaplar[kitapIndex].stok++;

            int fark = tarihGunFarki(oduncKayitlari[i].oduncTarih, iadeTarih);

            kitaplariKaydet();
            oduncKayitlariniKaydet();

            printf("Kitap iade edildi.\n");

            if(fark > ODUNC_SURESI) {
                printf("Gecikme var. Geciken gun: %d\n", fark - ODUNC_SURESI);
            } else {
                printf("Gecikme yok.\n");
            }

            return;
        }
    }

    printf("Aktif odunc kaydi bulunamadi.\n");
}

void oduncKayitlariniListele() {
    if(oduncSayisi == 0) {
        printf("Odunc kaydi yok.\n");
        return;
    }

    printf("\n--- ODUNC KAYITLARI ---\n");

    for(int i = 0; i < oduncSayisi; i++) {
        printf("Kullanici No: %s\n", oduncKayitlari[i].kullaniciNo);
        printf("ISBN: %s\n", oduncKayitlari[i].isbn);
        printf("Odunc Tarihi: %s\n", oduncKayitlari[i].oduncTarih);
        printf("Iade Tarihi: %s\n", oduncKayitlari[i].iadeTarih);
        printf("Durum: %s\n", oduncKayitlari[i].durum);
        printf("-------------------\n");
    }
}

void gecikenleriListele() {
    char bugun[15];
    int bulundu = 0;

    bugununTarihi(bugun);

    printf("\n--- GECIKEN KITAPLAR ---\n");

    for(int i = 0; i < oduncSayisi; i++) {
        if(strcmp(oduncKayitlari[i].durum, "IADE_EDILMEDI") == 0) {
            int fark = tarihGunFarki(oduncKayitlari[i].oduncTarih, bugun);

            if(fark > ODUNC_SURESI) {
                printf("Kullanici No: %s\n", oduncKayitlari[i].kullaniciNo);
                printf("ISBN: %s\n", oduncKayitlari[i].isbn);
                printf("Odunc Tarihi: %s\n", oduncKayitlari[i].oduncTarih);
                printf("Geciken Gun: %d\n", fark - ODUNC_SURESI);
                printf("-------------------\n");
                bulundu = 1;
            }
        }
    }

    if(!bulundu) {
        printf("Geciken kitap yok.\n");
    }
}
