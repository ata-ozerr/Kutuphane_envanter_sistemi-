#ifndef KITAP_H
#define KITAP_H

void kitaplariOku();
void kitaplariKaydet();
int isbnIleKitapBul(char isbn[]);
void kitapBilgiYazdir(int i);

void kitapEkle();
void kitapListele();
void kitapAra();
void kitapSil();
void kitapGuncelle();
void kitapSiralaAdaGore();

#endif
